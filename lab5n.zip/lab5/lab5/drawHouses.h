#include <iostream>
#include <cmath>
#include <stdlib.h>
#include <stdio.h>
#include "GL\glut.h"

using namespace std;

void drawMyHouse(GLuint texSet[]);